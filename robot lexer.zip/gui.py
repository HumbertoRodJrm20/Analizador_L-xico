import sys
import os
from PyQt5.QtWidgets import (
    QApplication, QWidget, QTextEdit, QTableWidget,
    QVBoxLayout, QTableWidgetItem, QSplitter, QPushButton, QGridLayout,
    QLabel, QMainWindow, QAction, QToolBar, QStatusBar, QFileDialog, 
    QMessageBox
)
from PyQt5.QtPrintSupport import QPrintDialog
from PyQt5.QtCore import Qt, QProcess, QProcessEnvironment
from PyQt5.QtGui import QFont, QFontDatabase, QIcon
from code_editor import CodeEditor
from my_lex import tabulate_tokens, execute, remove_color

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

class Ventana(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Lexer Gui Aero")
        self.resize(800, 600)

        # self.path holds the path of the currently open file.
        # If none, we haven't got a file open yet (or creating new).
        self.path = None

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)

        self.setWindowIcon(QIcon(resource_path("tako.ico")))

        font_family  = self.load_font(resource_path("scifi2k2.ttf"))
        mononoi_font = self.load_font(resource_path("mononoki-Regular.ttf"))

        fruti_font = QFont(font_family, 20)
        self.title = QLabel("Robot instructions lexer")
        self.title.setFont(fruti_font)

        self.run_button = QPushButton("Run")
        self.run_button.setFont(fruti_font)
        self.run_button.clicked.connect(self.load_tokens_table)

        self.header_layout = QGridLayout()
        self.layout.addLayout(self.header_layout)

        self.header_layout.addWidget(self.title, 0, 0)
        self.header_layout.addWidget(self.run_button, 0, 1)

        #----------------- Process run ---------------#

        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONIOENCODING", "utf-8")
        self.process = QProcess(self)
        self.process.setProcessEnvironment(env)

        self.process.readyReadStandardOutput.connect(self.handle_stdout)
        self.process.readyReadStandardError.connect(self.handle_stderr)
        self.process.finished.connect(self.process_finished)

        #----------------- Editor de codigo ---------------#

        font_size = 14
        self.editor = CodeEditor()
        self.editor.setPlaceholderText("Write some code here...")
        self.editor.setFont(QFont(mononoi_font, font_size))

        self.terminal = QTextEdit()
        self.terminal.setObjectName("terminal")
        self.terminal.setFont(QFont(mononoi_font, font_size))
        self.terminal.setReadOnly(True)
        self.py_mode = False
        self.py_path = None
        self.std_out = []

        #----------------- Tabla ---------------#
        self.tabla = QTableWidget(1, 2)  # 5 filas, 3 columnas
        self.tabla.setHorizontalHeaderLabels(["Token", "Tipo"])
        datos = []
        for fila, (nombre, edad, ciudad) in enumerate(datos):
            self.tabla.setItem(fila, 0, QTableWidgetItem(nombre))
            self.tabla.setItem(fila, 1, QTableWidgetItem(edad))
            self.tabla.setItem(fila, 2, QTableWidgetItem(ciudad))

        # ----------------- Output ---------------#


        # Layout
        self.splitter = QSplitter(Qt.Vertical)
        self.splitter.addWidget(self.editor)
        self.splitter.addWidget(self.tabla)
        self.splitter.setSizes([300, 300])

        self.layout.addWidget(self.splitter)
        self.layout.addWidget(self.terminal)

        # ------------------------  Toolbar y menus ---------------------------------------
        # Source: https://www.geeksforgeeks.org/creating-notepad-using-pyqt5-python/

        # creating a status bar object
        self.status = QStatusBar()

        # setting stats bar to the window
        self.setStatusBar(self.status)

        # creating a file tool bar
        file_toolbar = QToolBar("File")

        # adding file tool bar to the window
        self.addToolBar(file_toolbar)

        # creating a file menu
        file_menu = self.menuBar().addMenu("&File")

        # creating actions to add in the file menu
        # creating a open file action
        open_file_action = QAction("Open file", self)

        # setting status tip
        open_file_action.setStatusTip("Open file")

        # adding action to the open file
        open_file_action.triggered.connect(self.file_open)

        # adding this to file menu
        file_menu.addAction(open_file_action)

        # adding this to tool bar
        file_toolbar.addAction(open_file_action)

        # similarly creating a save action
        save_file_action = QAction("Save", self)
        save_file_action.setStatusTip("Save current page")
        save_file_action.triggered.connect(self.file_save)
        file_menu.addAction(save_file_action)
        file_toolbar.addAction(save_file_action)

        # similarly creating save action
        saveas_file_action = QAction("Save As", self)
        saveas_file_action.setStatusTip("Save current page to specified file")
        saveas_file_action.triggered.connect(self.file_saveas)
        file_menu.addAction(saveas_file_action)
        file_toolbar.addAction(saveas_file_action)

        # for print action
        print_action = QAction("Print", self)
        print_action.setStatusTip("Print current page")
        print_action.triggered.connect(self.file_print)
        file_menu.addAction(print_action)
        file_toolbar.addAction(print_action)

        # creating another tool bar for editing text
        edit_toolbar = QToolBar("Edit")

        # adding this tool bar to the main window
        self.addToolBar(edit_toolbar)

        # creating a edit menu bar
        edit_menu = self.menuBar().addMenu("&Edit")

        # adding actions to the tool bar and menu bar

        # undo action
        undo_action = QAction("Undo", self)
        # adding status tip
        undo_action.setStatusTip("Undo last change")

        # when triggered undo the editor
        undo_action.triggered.connect(self.editor.undo)

        # adding this to tool and menu bar
        edit_toolbar.addAction(undo_action)
        edit_menu.addAction(undo_action)

        # redo action
        redo_action = QAction("Redo", self)
        redo_action.setStatusTip("Redo last change")

        # when triggered redo the editor
        redo_action.triggered.connect(self.editor.redo)

        # adding this to menu and tool bar
        edit_toolbar.addAction(redo_action)
        edit_menu.addAction(redo_action)

        # cut action
        cut_action = QAction("Cut", self)
        cut_action.setStatusTip("Cut selected text")

        # when triggered cut the editor text
        cut_action.triggered.connect(self.editor.cut)

        # adding this to menu and tool bar
        edit_toolbar.addAction(cut_action)
        edit_menu.addAction(cut_action)

        # copy action
        copy_action = QAction("Copy", self)
        copy_action.setStatusTip("Copy selected text")

        # when triggered copy the editor text
        copy_action.triggered.connect(self.editor.copy)

        # adding this to menu and tool bar
        edit_toolbar.addAction(copy_action)
        edit_menu.addAction(copy_action)

        # paste action
        paste_action = QAction("Paste", self)
        paste_action.setStatusTip("Paste from clipboard")

        # when triggered paste the copied text
        paste_action.triggered.connect(self.editor.paste)

        # adding this to menu and tool bar
        edit_toolbar.addAction(paste_action)
        edit_menu.addAction(paste_action)

        # select all action
        select_action = QAction("Select all", self)
        select_action.setStatusTip("Select all text")

        # when this triggered select the whole text
        select_action.triggered.connect(self.editor.selectAll)

        # adding this to menu and tool bar
        edit_toolbar.addAction(select_action)
        edit_menu.addAction(select_action)


        # wrap action
        wrap_action = QAction("Wrap text to window", self)
        wrap_action.setStatusTip("Check to wrap text to window")

        # making it checkable
        wrap_action.setCheckable(True)

        # making it checked
        wrap_action.setChecked(True)

        # adding action
        wrap_action.triggered.connect(self.edit_toggle_wrap)

        # adding it to edit menu not to the tool bar
        edit_menu.addAction(wrap_action)

        # python mode for run codes
        py_action = QAction("Enable python mode", self)
        py_action.setStatusTip("Check to enable python mode")

        # making it checkable
        py_action.setCheckable(True)

        # making it checked
        py_action.setChecked(False)

        # adding action
        py_action.triggered.connect(self.enable_py_mode)

        # adding it to edit menu not to the tool bar
        edit_menu.addAction(py_action)

        # calling update title method
        self.update_title()

        # ------------------------ Estilo externo -------------------------
        with open(resource_path("style.css"), "r") as f:
            self.setStyleSheet(f.read())

    
    def load_font(self, path):
        """
        loads a font (ttf file) from its path source
        """
        id_font = QFontDatabase.addApplicationFont(path)
        if id_font != -1:
            font_name = QFontDatabase.applicationFontFamilies(id_font)[0]
            self.setFont(QFont(font_name, 11))
        else:
            print("No se pudo cargar la fuente.")

        return font_name
    
    # ------------ run method ------------
    def load_tokens_table(self):
        """
        load lexical tokens from the code written in the editor and showing the output in terminal 
        """

        if self.py_mode:
            self.execute_py()
            return
        
        code = self.editor.toPlainText()
        if len(code) != 0:
            data = tabulate_tokens(code, colors=False)['rows']
            self.tabla.setRowCount(len(data))
            for row, items in enumerate(data):
                for idx, item in enumerate(items):
                    self.tabla.setItem(row, idx, QTableWidgetItem(item))

        output = f">>> running...{execute(code, format=True)}"
        self.terminal.setText(output)


    # --------- metodos del toolbar y menus (source: Geeks for Geeks)
    # to show errors
    def dialog_critical(self, s):

        # creating a QMessageBox object
        dlg = QMessageBox(self)

        # setting text to the dlg
        dlg.setText(s)

        # setting icon to it
        dlg.setIcon(QMessageBox.Critical)

        # showing it
        dlg.show()

    # action called by file open action
    def file_open(self):

        # getting path and bool value
        path, _ = QFileDialog.getOpenFileName(self, "Open file", "", 
                             "Text documents (*.txt ); All files (*.*)")

        # if path is true
        if path:
            # try opening path
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    # read the file
                    text = f.read()

            # if some error occurred
            except Exception as e:

                # show error using critical method
                self.dialog_critical(str(e))
            # else
            else:
                # update path value
                self.path = path

                # update the text
                self.editor.setPlainText(text)

                # update the title
                self.update_title()

    # action called by file save action
    def file_save(self):

        # if there is no save path
        if self.path is None:

            # call save as method
            return self.file_saveas()

        # else call save to path method
        self._save_to_path(self.path)

    # action called by save as action
    def file_saveas(self):

        # opening path
        path, _ = QFileDialog.getSaveFileName(self, "Save file", "", 
                             "Text documents (*.txt ); All files (*.*)")

        # if dialog is cancelled i.e no path is selected
        if not path:
            # return this method
            # i.e no action performed
            return

        # else call save to path method
        self._save_to_path(path)

    # save to path method
    def _save_to_path(self, path):

        # get the text
        text = self.editor.toPlainText()

        # try catch block
        try:

            # opening file to write
            with open(path, 'w', encoding='utf-8') as f:

                # write text in the file
                f.write(text)

        # if error occurs
        except Exception as e:

            # show error using critical
            self.dialog_critical(str(e))

        # else do this
        else:
            # change path
            self.path = path
            # update the title
            self.update_title()

    # action called by print
    def file_print(self):

        # creating a QPrintDialog
        dlg = QPrintDialog()

        # if executed
        if dlg.exec_():

            # print the text
            self.editor.print_(dlg.printer())

    # update title method
    def update_title(self):

        # setting window title with prefix as file name
        # suffix as PyQt5 Notepad
        self.setWindowTitle("Kotanote - %s" %(os.path.basename(self.path) 
                                                  if self.path else "Untitled"))

    # action called by edit toggle
    def edit_toggle_wrap(self):

        # chaining line wrap mode
        self.editor.setLineWrapMode(1 if self.editor.lineWrapMode() == 0 else 0 )

    def get_real_python(self):
        if getattr(sys, 'frozen', False):
            import subprocess, platform
            if platform.system() == "Windows":
                return subprocess.check_output("where python", shell=True).decode().splitlines()[0]
            else:
                return subprocess.check_output("which python3", shell=True).decode().strip()
        else:
            return sys.executable
        
    def execute_py(self):

        if self.path is None:
            args = ["-c", self.editor.toPlainText()]
        else:
            args = ["-u", os.path.abspath(self.path)]

        self.process.setProcessChannelMode(QProcess.MergedChannels)

        self.process.setProgram(self.py_path)
        self.process.setArguments(args)

        self.std_out.clear()
        self.terminal.clear()
        self.process.start()
    
    def enable_py_mode(self):
        self.py_mode = not self.py_mode
        self.py_path = self.get_real_python()

    def handle_stdout(self):
        output = self.process.readAllStandardOutput().data().decode("utf-8", errors="replace")
        self.std_out.append(output)

    def handle_stderr(self):
        error = self.process.readAllStandardError().data().decode("utf-8", errors="replace")
        self.terminal.append(error)

    def process_finished(self):
        output = remove_color("".join(self.std_out), format=True)
        lines = output.split("\n")
        output = "".join([f"<br>{line}</br>" for line in lines])
        self.terminal.append(output)
        self.terminal.append("[end process]")



if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = Ventana()
    ventana.show()
    sys.exit(app.exec_())

# pyinstaller --onefile --windowed gui.py --add-data "scifi2k2.ttf;." --add-data "style.css;." --add-data "mononoki-Regular.ttf;." --add-data "parsetab.py;." --icon "tako.ico"

# ------------------------------------------------------------
# lex.py
#
# tokenizer for simple arm robot instructions
# ------------------------------------------------------------
import sys
import io
import re
import ply.lex as lex
import ply.yacc as yacc
from tabulate import tabulate

RESET = '\033[0m'
BOLD = '\033[1m'
UNDERLINE = '\033[4m'
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
MAGENTA = '\033[95m'
CYAN = '\033[96m'
WHITE = '\033[97m'

lineno = 1
line_code = ""

COLORS = [
    RESET,
    BOLD,
    RED,
    GREEN,
    YELLOW,
    BLUE,
    MAGENTA,
    CYAN,
    WHITE,
]

def nameof(value) -> str:
    for name, val in globals().items():
        if val is value:
            return name
    return None


color_dict = dict(zip(COLORS, [
    nameof(c)
    for c in COLORS
]))




class Robot:
    def __init__(self):
        self.velocidad = 0
        self.base = 0
        self.cuerpo = 0
        self.garra = 0
        self.init = False

    def set_value(self, name, value) -> None:
        if self.init:
            if   name == 'velocidad': self.velociddad = value
            elif name == 'base'     : self.base       = value
            elif name == 'cuerpo'   : self.cuerpo     = value
            elif name == 'garra'    : self.garra      = value
            print(f"{MAGENTA}{name} = {value}{RESET}")
        else: print(f"{RED}Inicialice el robot{RESET}")

    def action(self, name) -> None:
        if name == 'iniciar':
            self.init = True
            print(f"{BLUE}Iniciar robot{RESET}")
        if self.init:
            if name == 'cerrarGarra':
                print(f"{BLUE}Cerrar garra{RESET}")
            elif name == 'abrirGarra':
                print(f"{BLUE}Abrir garra{RESET}")
            elif name == 'print':
                print(f"{YELLOW}{self.__str__()}{RESET}")
        else: print(f"{RED}Inicialice el robot{RESET}")

    def __str__(self):
        return f"{self.velocidad=}, {self.base=}, {self.cuerpo=}, {self.garra=}"


RESET = '\033[0m'
BOLD = '\033[1m'
UNDERLINE = '\033[4m'
RED = '\033[91m'
GREEN = '\033[92m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
MAGENTA = '\033[95m'
CYAN = '\033[96m'
WHITE = '\033[97m'

# List of token names.   This is always required
tokens = (
    'Palabra_r',
    'Identificador',
    'Punto',
    'Metodo',
    'Accion',
    'Operador',
    'Valor',
    'IParentesis',
    'DParentesis',
    'IBucle',
    'FBucle',
    'newline'
)

# Regular expression rules for simple tokens
t_Palabra_r = r'Robot'
t_Identificador = r'(b|r)[0-9]'
t_Punto = r'\.'
t_Metodo = r'base|cuerpo|garra|velocidad'
t_Accion = r'iniciar|cerrarGarra|abrirGarra|print'
t_Operador = r'='
t_IParentesis = r'\('
t_DParentesis = r'\)'
t_IBucle = r'repetir'
t_FBucle = r'finRepetir'

# A regular expression rule with some action code
def t_Valor(t):
    r'(360|3[0-5][0-9]|[12]\d\d|\d\d|\d)'
    t.value = int(t.value)
    return t

# Define a rule so we can track line numbers
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# A string containing ignored characters (spaces and tabs)
t_ignore  = ' \t'

# Error handling rule
def t_error(t):
    global lineno
    print(f"{RED}Carácter ilegal '%s' en la línea %s {RESET}" % (t.value[0], lineno))
    t.lexer.skip(1)

# Build the lexer
lexer = lex.lex()

# ------------ Rules ------------

robots = dict()
loop = False
rt = 0
instructions = []

def p_statement_instance(p):
    'statement : Palabra_r Identificador'
    robots[p[2]] = Robot()

def p_statement_method(p):
    '''statement : Identificador Punto Metodo IParentesis Valor DParentesis
                | Identificador Punto Metodo Operador Valor 
    '''
    global loop
    try:
        robots[p[1]].set_value(p[3], p[5])
        if loop: 
            instructions.append((p[1], p[3], p[5]))

    except (LookupError, KeyError):
        print("Undefined name '%s'" % p[1])


def p_statement_action(p):
    'statement : Identificador Punto Accion IParentesis DParentesis'
    global loop
    try:
        robots[p[1]].action(p[3])
    except KeyError:
        print(f"{RED}Robot not declared {p}{RESET}")
    if loop:
        instructions.append((p[1], p[3], None))

def p_statement_begin_loop(p):
    'statement : Identificador Punto IBucle IParentesis Valor DParentesis'
    global loop, rt
    loop = True
    rt = p[5]
    instructions.clear()

def p_statement_end_loop(p):
    'statement : Identificador Punto FBucle IParentesis DParentesis'
    global loop, rt
    loop = False
    for _ in range(rt-1):
        for id, func, val in instructions:
            if val:
                robots[id].set_value(func, val)
            else:
                robots[id].action(func)
    rt = 0
    

def p_statement_newline(p):
    'statement : newline'
    pass


def p_error(p):
    global lineno, line_code
    val = p.value if p else line_code
    print(f"{RED}Error sintáctico en la línea {lineno} [{val}]{RESET}")

yacc.yacc(debug=False, write_tables=False)

def tokenize(code:str):
    # Give the lexer some input
    lexer.input(code)

    # Tokenize
    token_list = []
    while True:
        tok = lexer.token()
        if not tok:
            break      # No more input
        token_list.append(tok)

    return token_list

def tabulate_tokens(code:str, colors:bool) -> dict:
    tokens = tokenize(code)

    if colors:
        headers = [f'{BLUE}Token{RESET}', f'{CYAN}Tipo{RESET}', f'{MAGENTA}Valor{RESET}', f'{RED}Parametro{RESET}']
    else:
        headers = ['Token', 'Tipo']
    rows    = []

    for i, token in enumerate(tokens):
        token_name = token.value
        token_type = token.type

        if colors:
            rows.append([f'{BLUE}{token_name}{RESET}', f'{CYAN}{token_type}{RESET}'])
        else:
            rows.append([token_name, token_type])
    return {
        'headers': headers,
        'rows': rows
    }

def test():
    # Test it out
    code = """
    Robot r1
    r1.iniciar
    r1.velocidad=50
    r1.base=180
    r1.cuerpo=45
    r1.garra=0
    r1.cuerpo=90
    r1.garra=90
    """

    table = tabulate_tokens(code, True)
    print(tabulate(table['rows'], headers=table['headers']))

code1 = """
Robot r1
r1.iniciar(31)
r1.velocidad=abc
r1.basa()
r1.cuerpo=460
b1.garra=0
r1.garra(60, 60)
"""

def format_color(color:str) -> str:
    if color == RESET: return "</span>"
    else:
        try:
            return f'<span style="color: {color_dict[color].lower()};">'
        except KeyError:
            return '<span style="color: white;">'


def remove_color(s:str, format=False):
    colors = (re.findall("(\\033\[(\d|\d\d)m)", s))

    for color in colors:
        new_color = ""
        if format: new_color = format_color(color[0])
        s = s.replace(color[0], new_color)
    
    return f"<br>{s}</br>"

def execute(code:str, plain=True, format=False) -> str:
    #sys.stdout = open("salida.txt", "w", encoding="utf-8")

    global lineno, line_code
    lineno = 1

    buffer = io.StringIO()
    sys.stdout = buffer
    for inst in code.split('\n'):
        line_code = inst
        if len(inst.strip()) > 0:
            try:
                inst
            except EOFError:
                break
            yacc.parse(inst)
        lineno += 1
    sys.stdout = sys.__stdout__

    buff = buffer.getvalue()
    output = []
    if plain:
        for line in buff.split("\n"):
            output.append(remove_color(line, format))
    else:
        for line in buff.split("\n"):
            output.append(line)

    buffer.close()
    return '\n'.join(output)




if __name__ == '__main__':
    print(execute(code1, plain=False))

    

